if (!cordova) {
    var cordova = {};
    cordova.require = (() => {
        return ((name) => {
            if (name == "com.salesforce.plugin.oauth") {
                return (() => {
                    return {
                        authenticate: () => {
                            console.log("Authenticate from JS called")
                            return new Promise((resolve, reject) => {
                                window.webkit.messageHandlers.authenticate.postMessage({})
                                .then(data => resolve(data))
                                .catch(error => reject(error))
                            })
                        },

                        logout: () => {
                            console.log("logout current user from JS called")
                            return new Promise((resolve, reject) => {
                                window.webkit.messageHandlers.logoutCurrentUser.postMessage({})
                                .then(data => resolve(data))
                                .catch(error => reject(error))
                            })
                        },

                        getAuthCredentials: () => {
                            console.log("get auth credentials from JS called")
                            return new Promise((resolve, reject) => {
                                window.webkit.messageHandlers.getAuthCredentials.postMessage({})
                                .then(data => resolve(data))
                                .catch(error => reject(error))
                            })
                        },
                        getAppHomeUrl: () => {
                            console.log("get app home URL from JS called")
                            return new Promise((resolve, reject) => {
                                window.webkit.messageHandlers.getAppHomeUrl.postMessage({})
                                .then(data => resolve(data))
                                .catch(error => reject(error))
                            })
                        },
                    }
                })();
            } else if (name == "cordova/channel") {
                return {
                    onDeviceReady: {
                        state: 2
                    }
                }
            }
        })
    })();
}
