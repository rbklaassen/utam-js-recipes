var mycommunities = {};
mycommunities.nativejsapi = (() => {
    var clientFeatures = {};
	return {
		get deviceAttributes() {
			return new Promise((resolve, reject) => {
				window.webkit.messageHandlers.instrumentation.postMessage({})
                .then(data => resolve(data))
                .catch(error => reject(error))
			})
		},
        
        get clientFeatures() {
            return clientFeatures
        },
        set clientFeatures(json) {
            try {
                clientFeatures = JSON.parse(json)
                console.log(json)
            } catch(e) {
                throw e
            }
        },
        
        webAppBootstrapDone: (actionData) => {
            window.webkit.messageHandlers.webAppEventBootstrapDone.postMessage({data: actionData})
        },

        webAppReadyToReceiveAILTN: () => {
            mycommunities.nativejsapi.webAppPageLoadDone()
        },

        sendAILTNData: (payload, txnId) => {
            return new Promise((resolve, reject) => {
                window.native.sendAILTNData(payload, txnId)
                .then(identifier => resolve(identifier))
                .catch(error => reject(error))
            })
        },
        
        webAppPageLoadDone: () => {
            window.webkit.messageHandlers.webAppEventPageLoadDone.postMessage({})
        },

        invokeNative: (actionName, actionData) => {
            return new Promise((resolve, reject) => {
                window.webkit.messageHandlers.invokeNativeEvent.postMessage({action: actionName, data: actionData})
                .then(data => resolve(data))
                .catch(error => reject(JSON.parse(error.message)))
            })
        },
          
        refreshNotifications: () => {
            window.native.refreshNotifications()
        },
        
        navigateTo: (pageRef) => {
            window.native.navigateTo(pageRef)
        },
	}

})();
