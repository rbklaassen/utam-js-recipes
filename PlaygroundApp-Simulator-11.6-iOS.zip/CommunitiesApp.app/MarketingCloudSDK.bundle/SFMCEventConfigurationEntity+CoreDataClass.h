//
//  SFMCEventConfigurationEntity+CoreDataClass.h
//  
//
//  Created by iosadmin on 5/1/23.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface SFMCEventConfigurationEntity : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "SFMCEventConfigurationEntity+CoreDataProperties.h"
