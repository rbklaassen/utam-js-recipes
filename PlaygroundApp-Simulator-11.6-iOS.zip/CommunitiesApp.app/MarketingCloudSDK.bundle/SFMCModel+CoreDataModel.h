//
//  SFMCModel+CoreDataModel.h
//  
//
//  Created by iosadmin on 5/1/23.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#import "SFMCConfigurationEntity+CoreDataClass.h"
#import "SFMCEndpointConfigurationEntity+CoreDataClass.h"
#import "SFMCEventConfigurationEntity+CoreDataClass.h"




